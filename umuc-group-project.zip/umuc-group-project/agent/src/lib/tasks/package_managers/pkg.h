#ifndef _PKG_H
#define _PKG_H
#include "../dirwalk.h"
extern int query_pkg(char filepath[MAX_PATH_LENGTH]);
#endif
