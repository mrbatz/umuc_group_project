#ifndef _RPM_H
#define _RPM_H
#include "../dirwalk.h"
extern int query_rpm(char filepath[MAX_PATH_LENGTH]);
#endif
