#ifndef _APT_H
#define _APT_H
#include "../dirwalk.h"
extern int query_apt(char filepath[MAX_PATH_LENGTH]);
#endif
