#include <stdio.h>

#include "../package.h"
#include "../packagequery.h"
#include "../dirwalk.h"
#include "pacman.h"

extern int query_pacman(char filepath[MAX_PATH_LENGTH])
{
    return 0;
}
