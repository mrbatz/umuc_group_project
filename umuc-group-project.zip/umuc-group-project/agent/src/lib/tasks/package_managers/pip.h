#ifndef _PIP_H
#define _PIP_H
#include "../dirwalk.h"
extern int query_pip(char filepath[MAX_PATH_LENGTH]);
#endif
