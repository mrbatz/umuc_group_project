#ifndef _PACMAN_H
#define _PACMAN_H
#include "../dirwalk.h"
extern int query_pacman(char filepath[MAX_PATH_LENGTH]);
#endif
