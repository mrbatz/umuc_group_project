#ifndef _DPKG_H
#define _DPKG_H
#include "../dirwalk.h"
extern int query_dpkg(char fullpath[MAX_PATH_LENGTH]);
#endif
