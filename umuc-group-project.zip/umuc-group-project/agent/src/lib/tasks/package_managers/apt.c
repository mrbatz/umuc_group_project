#include <stdio.h>

#include "../package.h"
#include "../packagequery.h"
#include "../dirwalk.h"
#include "apt.h"

extern int query_apt(char filepath[MAX_PATH_LENGTH])
{
    return 0;
}
