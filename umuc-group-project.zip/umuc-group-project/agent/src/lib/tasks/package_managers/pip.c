#include <stdio.h>

#include "../package.h"
#include "../packagequery.h"
#include "../dirwalk.h"
#include "pip.h"

extern int query_pip(char filepath[MAX_PATH_LENGTH])
{
    return 0;
}

