#ifndef _YUM_H
#define _YUM_H
#include "../dirwalk.h"
extern int query_yum(char filepath[MAX_PATH_LENGTH]);
#endif
